<form action="create-user.php" method="post">
	<table>
		<tr>
			<td>Name:</td>
			<td><input type="text" name="user_name"/></td>
		</tr>
		<tr>
			<td>Avatar Filename:</td>
			<td><input type="text" name="user_avatar_filename"/></td>
		</tr>
		<tr>
			<td>Mobile:</td>
			<td><input type="text" name="user_mobile"/></td>
		</tr>
		<tr>
			<td>eMail:</td>
			<td><input type="text" name="user_email"/></td>
		</tr>
		<tr>
			<td><input type="submit" value="Submit"></td>
			<td></td>
		</tr>
	</table>
</form>