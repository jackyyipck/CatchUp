<?php 
include 'catchup-sql.php';

function init_db()
{
	if ($_SERVER["HTTP_HOST"] == "www.seayu.hk")
	{
		$_SESSION["db_conn"] = mysql_connect('localhost', 'seayu_catchup', 'anios');
	}else
	{
		$_SESSION["db_conn"] = mysql_connect('localhost', 'root', '');
	}
	mysql_select_db('seayu_catchup');
	mysql_set_charset('utf8');
}
function create_event_detail($db_conn, 
							$event_name, 
							$event_desc, 
							$expire_at, 
							$create_by, 
							$arr_option_name, 
							$arr_option_desc, 
							$arr_user_id)
{
	$event_id = create_event($db_conn, $event_name, $event_desc, $expire_at, $create_by);
	if ($event_id > 0)
	{
		for($i = 0; $i<count($arr_option_name); $i++)
		{			
			$option_id = create_option($db_conn, $arr_option_name[$i], $arr_option_desc[$i]);
			
			if($option_id > 0)
			{
				create_event_option_pair($db_conn, $event_id, $option_id);
			}
		}
		for($i = 0; $i<count($arr_user_id); $i++)
		{		
			create_event_user_pair($db_conn, $event_id, $arr_user_id[$i]);
		}
	}
	return $event_id;
}
function create_event_option_pair($db_conn, $event_id, $option_id)
{
	return mysql_query(create_event_option_pair_sql($event_id, $option_id), $db_conn);	
}
function remove_event_option_pair($db_conn, $event_id, $option_id)
{
	return mysql_query(remove_event_option_pair_sql($event_id, $option_id), $db_conn);	
}
function create_event_user_pair($db_conn, $event_id, $user_id)
{
	$result = mysql_query(create_event_user_pair_sql($event_id, $user_id), $db_conn);	
	if(!$result)
	{
		echo mysql_error();
	}
	else
	{
		return $result;
	}
}
function remove_event_user_pair($db_conn, $event_id, $user_id)
{
	return mysql_query(remove_event_option_pair_sql($event_id, $user_id), $db_conn);	
}
function create_event($db_conn, $event_name, $event_desc, $expire_at, $create_by)
{
	$event_id = 0;
	if (mysql_query(create_event_sql($event_name, $event_desc, $expire_at, $create_by), $db_conn))
	{
		$event_id = mysql_insert_id($db_conn);
	}
	return $event_id;
}
function remove_event($db_conn, $event_id)
{
	return mysql_query(remove_event_sql($event_id), $db_conn);	
}
function create_option($db_conn, $option_name, $option_desc)
{
	$option_id = 0;
	if (mysql_query(create_option_sql($option_name, $option_desc), $db_conn))
	{
		$option_id = mysql_insert_id($db_conn);
	}
	return $option_id;
}
function remove_option_event($db_conn, $option_id)
{
	return mysql_query(remove_option_sql($option_id), $db_conn);	
}
function create_vote($db_conn, $user_id, $option_id)
{
	return mysql_query(create_vote_sql($option_id, $user_id), $db_conn);
}
function remove_vote($db_conn, $user_id, $option_id)
{
	return mysql_query(remove_vote_sql($option_id, $user_id), $db_conn);
}
function create_user($db_conn, $user_name, $user_avatar_filename, $user_mobile, $user_email)
{
	$user_id = 0;
	$verification_code = rand(100000,999999);
	if (mysql_query(create_user_sql($user_name, $user_avatar_filename, $user_mobile, $user_email, $verification_code), $db_conn))
	{
		$user_id = mysql_insert_id($db_conn);
	}
	return array($user_id, $verification_code);
}
function remove_user($db_conn, $user_id)
{
	return mysql_query(remove_user_sql($user_id), $db_conn);	
}

?>