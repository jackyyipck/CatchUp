<b>Account Creation</b>
<form action="create-verify-user.php" method="post">
	<input type="hidden" name="action" value="create-user"/>
	<table>
		<tr>
			<td>Name:</td>
			<td><input type="text" name="user_name"/></td>
		</tr>
		<tr>
			<td>Avatar Filename:</td>
			<td><input type="text" name="user_avatar_filename"/></td>
		</tr>
		<tr>
			<td>Mobile:</td>
			<td><input type="text" name="user_mobile"/></td>
		</tr>
		<tr>
			<td>eMail:</td>
			<td><input type="text" name="user_email"/></td>
		</tr>
		<tr>
			<td><input type="submit" value="Submit"></td>
			<td></td>
		</tr>
	</table>
</form>
<b>Account Verification</b>
<form action="create-verify-user.php" method="post">
	<input type="hidden" name="action" value="verify-user"/>
	<table>
		<tr>
			<td>User ID:</td>
			<td><input type="text" name="user_id"/></td>
		</tr>
		<tr>
			<td>Verification Code:</td>
			<td><input type="text" name="verification_code"/></td>
		</tr>	
		<tr>
			<td><input type="submit" value="Submit"></td>
			<td></td>
		</tr>		
	</table>
</form>