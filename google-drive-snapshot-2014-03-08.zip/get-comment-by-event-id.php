<?php
include 'catchup-lib.php';

header("Content-Type: text/xml; charset=utf-8");

mysql_connect('localhost', 'seayu_catchup', 'anios');
mysql_select_db('seayu_catchup');
mysql_set_charset('utf8');

//XML compilation*****************
$response_row_node = new SimpleXMLElement("<?xml version='1.0' encoding='utf-8'?><response/>");

$comment_sql = get_comment_sql($_GET["event_id"]);
$comment_query_result = mysql_query($comment_sql);

while($comment_query_row = mysql_fetch_assoc($comment_query_result)) 
{
	$userdetail_sql = get_userdetails_sql($comment_query_row['create_by']);
	$userdetail_query_result = mysql_query($userdetail_sql);
	$userdetail_query_row = mysql_fetch_assoc($userdetail_query_result);
	
	$comment_name_node = $response_row_node->addChild('comment');
	$comment_name_node->addAttribute('comment_id',$comment_query_row['comment_id']);
	
	$comment_string_node = $comment_name_node->addChild('comment_string', nl2br(htmlspecialchars($comment_query_row['comment'])));
	$create_by_node = $comment_name_node->addChild('commenter', $userdetail_query_row['user_name']);
	$create_by_node->addAttribute('create_by',$comment_query_row['create_by']);	
	$create_by_node->addAttribute('create_at',$comment_query_row['create_at']);
	
}

mysql_free_result($userdetail_query_result);
mysql_free_result($comment_query_result);

echo $response_row_node->asXML();

?>