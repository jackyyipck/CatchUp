<form action="get-user-id-by-user-mobile.php" method="post">
	<table>
		<tr>
			<td>User mobile:</td>
			<td><input type="text" name="arr_user_mobile[]"/></td>
		</tr>
		<tr>
			<td>User mobile:</td>
			<td><input type="text" name="arr_user_mobile[]"/></td>
		</tr>
		<tr>
			<td>User mobile:</td>
			<td><input type="text" name="arr_user_mobile[]"/></td>
		</tr>
		<tr>
			<td><input type="submit" value="Submit"></td>
			<td></td>
		</tr>
	</table>
</form>