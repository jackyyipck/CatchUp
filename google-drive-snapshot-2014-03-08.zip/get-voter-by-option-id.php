<?php
include 'catchup-lib.php';

header("Content-Type: text/xml; charset=utf-8");

mysql_connect('localhost', 'seayu_catchup', 'anios');
mysql_select_db('seayu_catchup');
mysql_set_charset('utf8');

//XML compilation*****************
$option_node = new SimpleXMLElement('<option/>');

$voter_sql = get_voter_sql($_GET['option_id']);
$voter_query_result = mysql_query($voter_sql);

while($voter_query_row = mysql_fetch_assoc($voter_query_result)) 
{	
	$option_name_node = $option_node->addChild('voter_name', $voter_query_row['user_name']);
	$option_name_node->addAttribute('voter_id',$voter_query_row['user_id']);	
	$option_name_node->addAttribute('create_at',$voter_query_row['create_at']);	
}
mysql_free_result($voter_query_result);

echo $option_node->asXML();

?>