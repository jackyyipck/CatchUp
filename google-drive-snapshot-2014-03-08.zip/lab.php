<?php
//phpinfo();
echo mail("jackyyipck@gmail.com", "User registration", "test", "From: catchup@seayu.hk");
?>