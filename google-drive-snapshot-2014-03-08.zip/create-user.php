<?php
include 'catchup-lib.php';

echo create_user($_SESSION["db_conn"],
				$_POST["user_name"],
				$_POST["user_avatar_filename"],
				$_POST["user_mobile"],
				$_POST["user_email"]);

?>