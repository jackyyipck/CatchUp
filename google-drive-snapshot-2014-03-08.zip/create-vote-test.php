<form action="create-vote.php" method="post">
	<table>
		<tr>
			<td>User ID:</td>
			<td><input type="text" name="user_id"/></td>
		</tr>
		<tr>
			<td>Option ID:</td>
			<td><input type="text" name="option_id[]"/></td>
		</tr>
		<tr>
			<td>Option ID:</td>
			<td><input type="text" name="option_id[]"/></td>
		</tr>
		<tr>
			<td>Option ID:</td>
			<td><input type="text" name="option_id[]"/></td>
		</tr>
		<tr>
			<td>Option ID:</td>
			<td><input type="text" name="option_id[]"/></td>
		</tr>
		<tr>
			<td><input type="submit" value="Submit"></td>
			<td></td>
		</tr>
	</table>
</form>