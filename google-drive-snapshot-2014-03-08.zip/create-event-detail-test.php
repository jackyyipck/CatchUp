<form action="create-event-detail.php" method="post">
	<table>
		<tr>
			<td>Event Name:</td>
			<td><input type="text" name="event_name"/></td>
		</tr>
		<tr>
			<td>Event Desc:</td>
			<td><input type="text" name="event_desc"/></td>
		</tr>
		<tr>
			<td>Create by:</td>
			<td><input type="text" name="create_by"/></td>
		</tr>		
		<tr>
			<td>Expire at:</td>
			<td><input type="text" name="expire_at" value="2013-10-26 09:27:26"/></td>
		</tr>
		<tr>
			<td>Option Name:</td>
			<td><input type="text" name="option_name[]"/></td>
		</tr>
		<tr>
			<td>Option Desc:</td>
			<td><input type="text" name="option_desc[]"/></td>
		</tr>
		<tr>
			<td>Option Name:</td>
			<td><input type="text" name="option_name[]"/></td>
		</tr>
		<tr>
			<td>Option Desc:</td>
			<td><input type="text" name="option_desc[]"/></td>
		</tr>
		<tr>
			<td>Invite:</td>
			<td><input type="text" name="user_id[]"/></td>
		</tr>
		<tr>
			<td>Invite:</td>
			<td><input type="text" name="user_id[]"/></td>
		</tr>
		<tr>
			<td>Invite:</td>
			<td><input type="text" name="user_id[]"/></td>
		</tr>
		<tr>
			<td><input type="submit" name="submit" value="Submit"></td>
			<td></td>
		</tr>
	</table>
</form>